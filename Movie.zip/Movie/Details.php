<?php
  $con=mysqli_connect("localhost","root","","movie_tickets");
  if(!$con){
  echo "Connection failed";
  }
  ?>
  <?php
   session_start();
  if(!isset($_SESSION['name']))
  {
    
  
    header('location:login.php');
      ?>
<script>
    alert("Please login first");
</script>

<?php
  }
  ?>
<?php
$idd = $_GET['id'];
$showdata = "select * from `latestmovie` where ID = {$idd}";
// SELECT venues.Name,venues.Date1,venues.Date2,venues.Date3,venues.Time1,venues.Time2,venues.Time3,latestmovie.Name,latestmovie.Image,latestmovie.Description,latestmovie.Trailer FROM venues INNER JOIN latestmovie ON venues.MovieID=latestmovie.ID";

// $idd means theaterid in latesmovie
// $showdata =" select  latestmovie.Name,latestmovie.Image,latestmovie.Description,latestmovie.Trailer,venues.Date1,venues.Date2,venues.Date3,venues.Time1,venues.Time2,venues.Time3 FROM `venues` join latestmovie on venues.Movieid=latestmovie.TheaterID ;";

$result = mysqli_query($con,$showdata);
$arrdata = mysqli_fetch_array($result) or die( mysqli_error($db)); ;


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Details</title>
    <style>
        *{
            margin: 0;
            padding: 0;
        }
        .contain{
            background-image:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.3)),url('<?php echo $arrdata['Image']?>') ;
            background-position: center;
            background-size: cover;
            height: 900px;
            
        }
        .header{
            height:10% ;
        }
        .header-btn{
            text-decoration: none !important;
            border-radius: 30px;
            padding: 7px 20px;
            float: right;
            margin-top: 15px;
            color:#fff !important;
            background: #107afd;
            font-weight: 600;
            /* margin-right: 20px; */
        }
        .movie_details{
                margin: 5% 5%;
        }
        .left-box{
                color: white;
        }
        .casting img{
            height: 60px;
            width: 50px;
        }
        .left-box a{
            text-decoration: none !important;
            border-radius: 30px;
            padding: 7px 10px;
            margin-top: 35px;
            color:#fff !important;
            background: #107afd;
            font-weight: 600;
            display: inline-block;
            margin-right: 10%;
            background: transparent;
            border: 2px solid white;
        }
       .movie-image{
        height: 350px;
        box-shadow: -4px 4px 5px 0 #000;
        border: 2px solid white;
        width: 300px;
       }
       .right-box{
        text-align: center;
        padding-bottom: 10px;
       }
       .pop .overlay{
        position: fixed;
        top: 0px;
        left: 0px;
        width: 100vw;
        height: 100vw;
        background: rgba(0,0,0,0.7);
        z-index: 1;
        display: none;
       }
       .pop .content{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50% ) scale(0) ;
        background:#fff ;
        width: 800px;
        height: 500px;
        z-index: 2;
        text-align: center;
        padding: 20px;
        box-sizing: border-box;
       }
       .pop .close-btn{
        position: absolute;
        right: 20px;
        top: 20px;
        width: 30px;
        height: 30px;
        background:#222 ;
        color: #fff;
        font-size: 25px;
        font-weight:600 ;
        line-height: 30px;
        text-align: center;
        border-radius:50% ;
        cursor: pointer;
       }
       .pop.active .overlay{
        display: block;
       }
       .pop.active .content{
        transition: all 300ms ease-in-out;
        transform: translate(-50%, -50% ) scale(1) ;
       }
    </style>
</head>
<body>

<?php

?>


    <div class="contain">
    <div class="container header">
        
        <a href="logout.php" class="header-btn btn btn-success">Logout</a>

    </div>
    
    <div class="container movie_details">
        <div class="row">
            <div class="col-md-6 left-box">
                <h1><?php echo $arrdata['Name']?></h1>
                <p><?php echo $arrdata['Description']?></p>
                <p>Cast</p>
                <div class="casting">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPCtjSsj4MMLAiA3whZQrN9ipg6W3769OgMw&usqp=CAU" alt="">
                    <img src="fotoo/maleactor.jpg " alt="">
                    <img src=" fotoo/femaleactor.jpg" alt="">
                    <img src="fotoo/producer.jpg" alt="">
                    <img src=" fotoo/maleactor.jpg" alt="">
                </div>
                <br>
               
                <div class="pop" id="popup1" style="color:black ;">
                    <div class="overlay"></div>
                        <div class="content">
                            <div class="close-btn" style=" position: absolute;
                            right: 20px;
                            top: 20px;
                            width: 30px;
                            height: 30px;
                            background:#222 ;
                            color: #fff;
                            font-size: 25px;
                            font-weight:600 ;
                            line-height: 30px;
                            text-align: center;
                            border-radius:50% ;
                           " onclick="togglepopup()">&times;</div>
                            <h3>Trailer</h3>
                            <div class="trailer ">
                                <iframe width="700px" height="400px" src="<?php echo $arrdata['Trailer']?>" title="YouTube video player" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>
                </div>
<button  onclick="togglepopup()" style=" text-decoration: none !important;border-radius: 30px;padding: 7px 10px;margin-top: 35px;color:#fff !important;background: #107afd;font-weight: 600;display: inline-block;margin-right: 10%;background: transparent;border: 2px solid white;" >
    Watch Trailer
  </button>

  <script> 
function togglepopup(){
    document.getElementById("popup1").classList.toggle("active");
 

    
}


</script>
  
 
                  
            </div>
            <div class="col-md-6 right-box"  >
                <br>
                <img src="<?php echo $arrdata['Image']?>" class="movie-image" alt="">
                
            </div>
        </div>
    </div>


</div>



    
                                                                <!-- details -->




<br>
<br>
<br>
<hr>

<div class="container " style="background-color: white;margin: auto ;">
    <p style="text-align:center;  font-size: 25px; padding: 0%; margin: 0%;"> Displaying Details </p>
    <hr>
    <div class="content">


        <div class="row">
            <div class="col-md-4" >
                <img height="350px" width="250px" src="<?php echo $arrdata['Image']?>" alt="">
                <br clear="">
            </div>

            <div class="col-md-5 " style="font-weight:bold ; font-size: large;">
                <br>
                Movie Name: &nbsp &nbsp &nbsp <?php echo $arrdata['Name']?>
                <hr>
                Description: &nbsp &nbsp &nbsp Entertainment
                <hr>
                Director: &nbsp &nbsp &nbsp John
                <hr style="height: 5px; color:#ff4d4d">


                
                                
                <table class="table" style="text-align: center;">
                    <thead>
                
                
                
                
                      <tr>
                        
                        <th scope="col">Cinema</th>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                        <th scope="col">Action</th>
                        <!-- <th scope="col">Date</th> -->
                      </tr>
                    </thead>
                    <tbody>


                  
                  <?php 
                  $Movie_theater =$arrdata['Theater_ID']; 
         

                $dataqry = "select * from venues where ID = $Movie_theater    ";

                
                $res = mysqli_query($con,$dataqry);
                $vendata = mysqli_fetch_array($res);

                // while($ven = mysqli_fetch_array($res)){
                    ?>
                      <tr>
                        
                        <td name="movnam"><?php echo $vendata['Name'] ?></td>
                        
                        <td>
                            
                        <form action="" method="POST">
                            <select name="datelist[]" id="">
                            <option value="">Select.....</option>
                                <option value="<?php echo $vendata['Date1'] ?>"><?php echo $vendata['Date1'] ?></option>
                                <option value="<?php echo $vendata['Date2'] ?>"><?php echo $vendata['Date2'] ?></option>
                                <option value="<?php echo $vendata['Date3'] ?>"><?php echo $vendata['Date3'] ?></option>
                            </select>
                        </td>
                        <td>
                            <select  name="timelist[]" id="">
                            <option value="">Select.....</option>
                                <option value="<?php echo $vendata['Time1'] ?>"><?php echo $vendata['Time1'] ?></option>
                                <option value="<?php echo $vendata['Time2'] ?>"><?php echo $vendata['Time2'] ?></option>
                                <option value="<?php echo $vendata['Time3'] ?>"><?php echo $vendata['Time3'] ?></option>
                            </select>
                        </td>
                        <!-- for fetch particular time and date from drop down -->
                                                    <?php
                            if(isset($_POST['book'])){
                            $Date = $_POST['datelist'];
                            foreach($Date as $sdate){
                                $selected_date = $sdate;
                            }
                            }

                            if(isset($_POST['book'])){
                                $Time = $_POST['timelist'];
                                foreach($Time as $stime){
                                    $selected_Time = $stime;
                                }
                                }
                            ?>
                            
                            <!-- for save date and time  -->
                        <td> <input type="submit"  class="btn btn-primary" name="book"  value="Save "> </td>
                      </tr>

                     <tr>
                        
                     </tr>
                      
                   
                    </tbody>
                  </table>
                    
                <hr>

<hr>
                Select Category: &nbsp &nbsp &nbsp
                 <select >
                    <option >Diamond</option>
                    <option >Gold</option>
                    <option >Silver</option>
                    <option >Plantinum</option>
                </select>

                </form>
                <hr>
                
                
                <?php 

$Username= $_SESSION['name'];
$selected_Movie = $arrdata['Name'];

// $selected_Time = $stime;
$Theater = $vendata['Name'];


// echo $Username."<br>";
// echo $selected_Movie."<br>";
// echo $selected_Time."<br>";
// echo $selected_date."<br>";
// echo $Theater ."<br>";

$Details = array($Username,$selected_Movie,$Theater,$selected_Movie,$selected_date);


?>                       
                
           
                <!-- <input type="submit"  class="btn btn-success" name="book_data"  > -->
               <a href="booking/index.php?arr=$Details" class="btn btn-success">Next</a>
            </div>


        </div>


        <div>
        </div>
       
        

<br><br>

      

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<br><br>
</body>
</html>