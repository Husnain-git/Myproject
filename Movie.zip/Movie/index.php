<!DOCTYPE html>
<!--
ustora by freshdesignweb.com
Twitter: https://twitter.com/freshdesignweb
URL: https://www.freshdesignweb.com/ustora/
-->
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ustora Demo</title>

<!-- Google Fonts -->
<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.min.css">

<!-- Font Awesome -->
<link rel="stylesheet" href="css/font-awesome.min.css">

<!-- Custom CSS -->
<link rel="stylesheet" href="css/owl.carousel.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/responsive.css">


<style>
.btn-primary:hover{
color:#17a78b;
}
</style>
</head>
<body>

<?php
$con=mysqli_connect("localhost","root","","movie_tickets");
if(!$con){
echo "Connection failed";
}


session_start();

  

?>


<div class="header-area" style="background-color: #2E2E2E; color:white ">
<div class="container" >
<div class="row">
<div class="col-md-8">
<div class="user-menu">
<ul >
<li style="margin-right:30px; font-size:15px;text-transform:uppercase;"> <?php 
  if(isset($_SESSION['name']))
  {
    ?>
    <i class="fa fa-user"></i>
    <?php
    echo "Welcome  " . $_SESSION['name']."!" ; 
  } 
  
 ?> 
 </li>
    <li style="color: white;"><a href="#"><i class="fa fa-user"></i> My Account</a></li>
    
    <li><a href="#"><i class="fa fa-user"></i> My Cart</a></li>
    
    
</ul>
</div>
</div>

<div class="col-md-4">
<div class="header-right">
<ul class="list-unstyled list-inline">
    
    <li>
        <a class="mod_log" href="login.php"> <button  type="button" style="background-color: #2E2E2E; border:none;" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
            <i class="fa fa-user"></i> Login
            </button></a></li>
        <!-- Button trigger modal -->



    <li>
    </li>
    <li><a href="signup.php"><i class="fa fa-user"></i> Signup</a></li>
</ul>
</div>
</div>
</div>
</div>
</div> <!-- End header area -->


<?php
// if( empty(session_id()) && !headers_sent()){

if($_SERVER['REQUEST_METHOD']=='POST'){
if(isset($_POST['signup'])){
$username = $_POST['uname'];
$pass = $_POST['pass'];
$sql="select* from signup where Username ='$username' and Password = '$pass'  ";
$res = mysqli_query($con,$sql);
if($res){
$num = mysqli_num_rows($res);
if($num>0){

$_SESSION['username']=$username;
header('Location: index.php');
?>
<script>
alert("login and session created");
</script>
<?php
}
else{
?>
<script>
alert("login and session Failed");
</script>
<?php
// echo('Login Error');
}
}

}
}



?>


</div>
</div>
</div> <!-- End site branding area -->


<br>
<div class="mainmenu-area">
<div class="container">
<div class="row">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div> 
<div class="navbar-collapse collapse">
<ul class="nav navbar-nav">
<li class="active"><a href="index.php">Home</a></li>
<li><a href="#upmovie">Upcoming Movies</a></li>
<li><a href="#Latmovie">Latest Movie</a></li>
<li><a href="#spons">Sponores</a></li>
<li><a href="#Foot">Contact</a></li>
<!-- <li><a href="#">Category</a></li>
<li><a href="#">Others</a></li>
<li><a href="#">Contact</a></li> -->
</ul>
</div>  
</div>
</div>
</div> <!-- End mainmenu area -->

    <!-- php work for login -->
<?php
if( empty(session_id()) && !headers_sent()){
session_start();
if($_SERVER['REQUEST_METHOD']=='POST'){
if(isset($_POST['signup'])){
$username = $_POST['uname'];
$pass = $_POST['pass'];
$sql="select * from signup where Username ='$username' and Password = '$pass'  ";
$res = mysqli_query($con,$sql);
if($res){
$num = mysqli_num_rows($res);
if($num>0){
$_SESSION['name']=$username;
header('Location: Movie/Details.php');
?>
<script>
alert("login");
</script>
<?php
}
else{
?>
<script>
alert("login Failed");
</script>
<?php
// echo('Login Error');
}
}

}
}
}


?>

<br>
<h1 style="Text-align: center;font-family: 'Courier New', Courier, monospace; font-weight: bold;">Upcomming Movies</h1>

<div class="slider-area" id="upmovie">
<!-- Slider -->
<div class="block-slider block-slider4">
<ul class="" id="bxslider-home4">
<?php
$qry = "select* from upcoming_movies";
$res =mysqli_query($con,$qry);
while($data = mysqli_fetch_array($res)){
?>
<li>
<img src="<?php echo $data['Image'] ?>" style="height:500px;" alt="Slide">

</li>

<?php
}
?>			


</ul>
</div>
<!-- ./Slider -->
</div> <!-- End slider area -->



<div class="maincontent-area" id="Latmovie">
<div class="zigzag-bottom"></div>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="latest-product">
<h2 class="section-title">Latest Movies</h2>
<div class="product-carousel">
<?php
$qry2 = "select* from latestmovie";
$res =mysqli_query($con,$qry2);
while($lat = mysqli_fetch_array($res)){
?>
<!-- start -->

<div class="single-product">

    
        <div class="product-f-image">
            <img src="<?php echo $lat['Image'] ?>" style="height:400px;" alt="">
            <div class="product-hover">
                <!-- <a href="#" class="add-to-cart-link"><i class="fa fa-shopping-cart"></i>Book Now</a> -->
                <a href="Details.php?id=<?php  echo $lat['ID'] ?>" class="view-details-link"><i class="fa fa-link"></i> See details</a>
            </div>
        </div>
        
        <h2><a href="single-product.html"><?php echo $lat['Name'] ?></a></h2>
        <div class="product-carousel-price">
            <!-- <ins>$700.00</ins> <del>$100.00</del> -->
        </div> 
        </div>

        
    
    <!-- end -->
<?php
}
?>
</div>
</div>
</div>
</div>
</div>
</div> <!-- End main content area -->

<div class="brands-area" id="spons">
<h2 class="section-title" style="font-weight:bold; font-family: 'Courier New', Courier, monospace; color: black;">Sponsored By:</h2>
<div class="zigzag-bottom"></div>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="brand-wrapper">
<div class="brand-list">
    <?php
                    
    $qry3 = "select* from spon";
    $res =mysqli_query($con,$qry3);
    while($img = mysqli_fetch_array($res)){
    
    ?>
    <img style="height: 200px;" src="<?php echo $img['Sponsoredby'] ?>" alt="">
    
    <?php
    }
    ?>
    
</div>
</div>
</div>
</div>
</div>
</div> 
<br><br><br><br><!-- End brands area -->



<div class="footer-top-area" id="Foot">
<div class="zigzag-bottom"></div>
<div class="container">
<div class="row">
<div class="col-md-3 col-sm-6">
<div class="footer-about-us">
<h2>u<span>Stora</span></h2>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis sunt id doloribus vero quam laborum quas alias dolores blanditiis iusto consequatur, modi aliquid eveniet eligendi iure eaque ipsam iste, pariatur omnis sint! Suscipit, debitis, quisquam. Laborum commodi veritatis magni at?</p>
<div class="footer-social">
    <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
    <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
    <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
    <a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
</div>
</div>
</div>

<div class="col-md-3 col-sm-6">
<div class="footer-menu">
<h2 class="footer-wid-title">User Navigation </h2>
<ul>
    <li><a href="#">My account</a></li>
    <li><a href="#">Order history</a></li>
    <li><a href="#">Wishlist</a></li>
    <li><a href="#">Vendor contact</a></li>
    <li><a href="#">Front page</a></li>
</ul>                        
</div>
</div>

<div class="col-md-3 col-sm-6">
<div class="footer-menu">
<h2 class="footer-wid-title">Categories</h2>
<ul>
    <li><a href="#">Mobile Phone</a></li>
    <li><a href="#">Home accesseries</a></li>
    <li><a href="#">LED TV</a></li>
    <li><a href="#">Computer</a></li>
    <li><a href="#">Gadets</a></li>
</ul>                        
</div>
</div>

<div class="col-md-3 col-sm-6">
<div class="footer-newsletter">
<h2 class="footer-wid-title">Newsletter</h2>
<p>Sign up to our newsletter and get exclusive deals you wont find anywhere else straight to your inbox!</p>
<div class="newsletter-form">
    <form action="#">
        <input type="email" placeholder="Type your email">
        <input type="submit" value="Subscribe">
    </form>
</div>
</div>
</div>
</div>
</div>
</div> <!-- End footer top area -->

<div class="footer-bottom-area">
<div class="container">
<div class="row">
<div class="col-md-8">
<div class="copyright">
<!-- <p>&copy; 2015 uCommerce. All Rights Reserved. <a href="http://www.freshdesignweb.com" target="_blank">freshDesignweb.com</a></p> -->
</div>
</div>

<div class="col-md-4">
<div class="footer-card-icon">
<i class="fa fa-cc-discover"></i>
<i class="fa fa-cc-mastercard"></i>
<i class="fa fa-cc-paypal"></i>
<i class="fa fa-cc-visa"></i>
</div>
</div>
</div>
</div>
</div> <!-- End footer bottom area -->

<!-- Latest jQuery form server -->
<script src="https://code.jquery.com/jquery.min.js"></script>

<!-- Bootstrap JS form CDN -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<!-- jQuery sticky menu -->
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.sticky.js"></script>

<!-- jQuery easing -->
<script src="js/jquery.easing.1.3.min.js"></script>

<!-- Main Script -->
<script src="js/main.js"></script>

<!-- Slider -->
<script type="text/javascript" src="js/bxslider.min.js"></script>
<script type="text/javascript" src="js/script.slider.js"></script>
</body>
</html>