<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
    <style>
      html {
  height: 100%;
}
body {
  margin:0;
  padding:0;
  font-family: sans-serif;
  background: linear-gradient(#e66465, #719);
}
        .container {
  margin: auto;
  /* width :900px; */
  text-align:left;
  
  }
  .container h1,h2{
    text-align:center;
  }
  .container h3{
    text-align:center;
    margin-top: 5px;
  }
  label{
  font-weight:bold;
  font-size:20px;
  color:#6E2C00;
  
}
  input[type=text] {
   border: 3px solid black;
}
input[type=text]:hover {
   border: 3px solid skyblue;
}

input[type=Password] {
   border: 3px solid black;
}
input[type=Password]:hover {
  border: 3px solid skyblue;
}

input[type=Email] {
   border: 3px solid black;
}
input[type=Email]:hover {
   border: 3px solid skyblue;
}
button{
  background-color:#DC7633 ;
  color:white;
}
button:hover{
  transform: translatey(3px);
  transition:0.2s;
}


label{
  font-weight:bold;
  font-size:20px
}
.dlt_btn{
  Background-color:red; padding: 7px; width:50px; border-radius:5px; text-align:center; Text-decoration:none; color: white;
  text-transform: uppercase;

}
.dlt_btn:hover{
  Background-color:red; padding: 7px; width:50px; border-radius:5px; text-align:center; Text-decoration:none; color: white;
  text-transform: uppercase;
 transform: translateY(3px);
 transition-duration: 0.1s;
 
}

.upd{
  Background-color:#FFBF00; padding: 7px; width:50px; border-radius:5px; text-align:center; Text-decoration:none; color: white;
  
}
.upd:hover{
  Background-color:#FFBF00; padding: 7px; width:50px; border-radius:5px; text-align:center; Text-decoration:none; color: white;
  transform: translateY(3px);
 transition-duration: 0.1s;
}
.login-box {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 400px;
  padding: 40px;
  transform: translate(-50%, -50%);
  background: linear-gradient(#e66465, #9198e5);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgba(0,0,0,.6);
  border-radius: 10px;
}
.form-group{
  position: relative;
}

.login-box .form-group input:focus ~ label,
.login-box .form-group input:valid ~ label {
  top: -20px;
  left: 0;
  color: #03e9f4;
  font-size: 12px;
}
h2{
  color:white;
  font-size:30px;
}
 </style>
</head>
<body>

<?php

$con=mysqli_connect("localhost", "root", "","movie_tickets") or die(mysql_error());

if(!$con){
echo "Connection failed";
}

?>

<!-- php work  for insert the  data into database -->
<?php
  if($_SERVER['REQUEST_METHOD'] == 'POST')
  {
  if(isset($_POST['signup'])){
    
  $uname = $_POST['username'];
  $pass = $_POST['pass'];
  $Email = $_POST['email'];
  // $Phone = $_POST['phone'];
  $Address = $_POST['address'];
  
  

  if($uname !=null && $pass!=null && $Email!=null  && $Address!=null ){
    // && $Phone!=null

  $sql = "select* from `signup`  WHERE 	Username = '$uname' " ;

  $result=mysqli_query($con,$sql);

    if($result){
    $num =mysqli_num_rows($result);

  if($num>0){
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Notice!</strong>User already exist!
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
  </button>
  </div> ';
    }
  else{
  $sql = "insert into `signup` values('','$uname','$pass','$Email','$Address') ";
  $result=mysqli_query($con,$sql);

  if($result){
  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success!</strong>Your Username ' .$uname . ' and password has been submitted successfully!
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
  </button>
  </div> ';
  }
      else{
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error!</strong>Insertion failed!
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
  </button>
  </div> ';
  }
    
  }
    }

  }
  else{
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error!</strong>Please enter Required data.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
  </button>
  </div> ';
  }
  }
  }

?>
 


   
<br><br>
                                    <!-- add emplpoyee form popup Modal Body-->
  <div class="container mt-2">
  <h2>Enter The Given Data</h2>
  
  <hr>
  <form  class="form_control  mx-3"  method="POST">
  
  <div class="login-box">
  <br>
  <div class="form-row">
  <div class="form-group col-sm-6">
  <label for="username">Username:</label>
  <input type="text" class="form-control" name="username" id="username" placeholder="Enter Username">
  </div>
  <div class="form-group col-sm-6">
  <label for="address">Password:</label>
  <input type="text" class="form-control" name="pass" id="username" placeholder="Enter Password">
  </div>
  <div class="form-group col-sm-6">
    <label for="inputEmail4">Email:</label>
    <input type="email" class="form-control" name="email" id="Email" placeholder="Enter Email">
  </div>
  <!-- <div class="form-group col-sm-6">
  <label for="phone number">Phone Number:</label>
  <input type="text" class="form-control" name="phone" id="username" placeholder="Enter Phone Number">
  </div> -->
  <div class="form-group col-sm-6">
  <label for="address">Address:</label>
  <input type="text" class="form-control" name="address" id="username" placeholder="Enter Address">
  </div>
  
  

  </div>
  <!-- <input type="submit"  name="signup" class="btn  mt-3" value="Submit"> -->
  <button  type="submit" name="signup" class="btn  mt-3">Sign up</button>
  <!-- <button  type="submit" name="signup" class="btn  mt-3">Submit</button> -->
  <br>
  <br>
</div>
  </form>
  </div>
   

  

    
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<!-- <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script> -->
<!-- <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script> -->

</body>
</html>