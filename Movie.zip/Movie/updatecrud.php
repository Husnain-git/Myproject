<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<style>
  .container {
  margin: auto;
  /* width :900px; */
  text-align:left;
  
  }
  .container h1{
    text-align:center;
  }
  .container h3{
    text-align:center;
    margin-top: 5px;
  }
  label{
  font-weight:bold;
  font-size:20px;
  color:#6E2C00;
  
}
  input[type=text] {
   border: 3px solid black;
}
input[type=text]:hover {
   border: 3px solid skyblue;
}

input[type=Password] {
   border: 3px solid black;
}
input[type=Password]:hover {
  border: 3px solid skyblue;
}

input[type=Email] {
   border: 3px solid black;
}
input[type=Email]:hover {
   border: 3px solid skyblue;
}
button{
  background-color:#DC7633 ;
  color:white;
}
button:hover{
  transform: translatey(3px);
  transition:0.2s;
}


label{
  font-weight:bold;
  font-size:20px
}
/* .form-row a:hover{
    
} */

</style>
<body>
   
<?php
    $con= mysqli_connect("localhost","root","","movie_tickets");
    if(!$con){
        echo "Connection failed";
    }
    ?>

    <?php
    $idd = $_GET['id'];
    $showdata = "select * from `upcoming_movies` where ID = {$idd}";
    $result = mysqli_query($con,$showdata);
    $arrdata = mysqli_fetch_array($result) ;

    if(isset($_POST['update']))
{
    $user = $_POST['name'];
    $image = $_FILES['files'];
    $image_name = $image['name'];
    echo "<br>";
    echo "<br>";

    $image_temp = $image['tmp_name'];
    $image_error= $image['error'];
    
    $seperator= explode('.', $image_name);
    $lower = strtolower(end($seperator));
  

    $extension= array('jpg','jpeg','png',);
    echo "<br>";

    if(in_array($lower,$extension)){

        $upimage = 'fotoo/'.$image_name;
        move_uploaded_file($image_temp,$upimage);

        // $sql="insert into `upcoming_movies`(Name,Image) values ('$user','$upimage')" ;
        $sql="update upcoming_movies set Name = ' $user', Image = '$upimage' WHERE ID = '$GET[id]' "; //ID must be explain
        $res = mysqli_query($con,$sql) or die( mysqli_error($db));

        if($res){

          ?>

          <script>
            // echo"Uploaded successfully!";
            alert("Updated Successfully");
            </script>

            <?php
        }
        else{
            echo"Updating Failed";
        }
    }


}


?>


<!-- Form -->
    
<div class="container mt-5">
<h3>Update the Data..</h3>

<form  class="form_control mt-5 mx-5" action="#" method="POST" enctype="multipart/form-data">

<br>
  <div class="form-row">
  <div class="form-group col-sm-6">
      <label for="username">Name:</label>
      <input type="text" class="form-control" name="name" id="username" value="<?php echo $arrdata['Name']?>" >
    </div>

      <div class="form-group col-sm-6">
        <label for="image">Image:</label>
        <input type="file" class="form-control" name="files"  value="<?php echo $arrdata['Image']?>">
      
      </div>
      </div>
  <button  type="submit" name="update" class="btn  mt-3">Update</button>
  <br><br>
  <a style="text-decoration:none; background-color: black; color: white; padding:5px; border-radius:5px;" href="Sliderupcoming.php">Check now</a>
  <br>
  <br>
</form>
</div>

 

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  

</body>
</html>