
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
  </head>
<style>
   .btn-primary:hover{
            color:#17a78b;
        }
  /* .container {
  margin: auto;
  width :900px;
  text-align:left;
  
  } */
  .container h1{
    text-align:center;
  }
  .container h3{
    text-align:center;
    margin-top: 5px;
  }
  label{
  font-weight:bold;
  font-size:20px;
  color:#6E2C00;
  
}
  input[type=text] {
   border: 3px solid black;
}
input[type=text]:hover {
   border: 3px solid skyblue;
}

input[type=Password] {
   border: 3px solid black;
}
input[type=Password]:hover {
  border: 3px solid skyblue;
}

input[type=Email] {
   border: 3px solid black;
}
input[type=Email]:hover {
   border: 3px solid skyblue;
}
button{
  background-color:#DC7633 ;
  color:white;
}
button:hover{
  transform: translatey(3px);
  transition:0.2s;
}


label{
  font-weight:bold;
  font-size:20px
}
.dlt_btn{
  Background-color:red; padding: 7px; width:50px; border-radius:5px; text-align:center; Text-decoration:none; color: white;
  text-transform: uppercase;

}
.dlt_btn:hover{
  Background-color:red; padding: 7px; width:50px; border-radius:5px; text-align:center; Text-decoration:none; color: white;
  text-transform: uppercase;
 transform: translateY(3px);
 transition-duration: 0.1s;
 
}

</style>
<body>
<div class="header-area" style="background-color: #2E2E2E; color:white ">
        <div class="container" >
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul >
                            <li style="color: white;"><a href="#"><i class="fa fa-user"></i> My Account</a></li>
                            <li><a href="#"><i class="fa fa-heart"></i> Wishlist</a></li>
                            <li><a href="cart.html"><i class="fa fa-user"></i> My Cart</a></li>
                            <li><a href="checkout.html"><i class="fa fa-user"></i> Checkout</a></li>
                            <!-- <li><a href="#"><i class="fa fa-user"></i> Login</a></li> -->
                        </ul>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="header-right">
                        <ul class="list-unstyled list-inline">
                           
                            
                            </li>
                            <li><a href="#"><i class="fa fa-user"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
  $con=mysqli_connect("localhost","root","","movie_tickets");
  if(!$con){
  echo "Connection failed";
  }
  ?>


                                    
              
<!-- End slider area -->
    
    <div class="promo-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo1">
                      <a href="dashboard.php" style="color:white"> <i class="fa fa-refresh"></i>
                        <p>Upcoming Movies</p></a>
                       
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo2">
                    <a href="latestmovie.php" style="color:white"> <i class="fa fa-refresh"></i>
                        <p>Latest Movies</p></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo3">
                    <a href="" style="color:white"> <i class="fa fa-refresh"></i>
                        <p>Venues</p></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo4">
                    <a href="Sponsored.php" style="color:white"> <i class="fa fa-refresh"></i>
                        <p>Sponsored</p></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <!-- End promo area -->



                                     <!-- navbar2 -->

<div class="container ml-10 ">

<nav class="navbar navbar-light" style="background-color:#5a88ca;">
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
  <span style="color:white;font-size:30px; font-family:sans sarif; margin:10px;">Slider Images</span>
  <div class="log">
  <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Open modal for @mdo</button> -->
                    
                            <!-- Search bar and button -->
<form action="#" method="GET">
  <input style="width:200px; height: 35px; border-radius: 5px " type="text" placeholder="Search Employee" name="search">
  <input style="background-color:black; color:white;  border-radius:5px;" type="submit" value="Search" required value="<?php if(isset($_GET['search'])){ echo $_GET['search']; }?> ">

  <button type="button" class="btn btn-info p-2 m-3" style="background-color:Black; color: white; border: none;"  data-toggle="modal" data-target="#exampleModalCenter">+Slider</button>
</form>


                                <!-- add slider image popup Modal Body-->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="text-align: left; color: black;">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" style="font-weight: bold;" id="exampleModalLongTitle">Add Slider</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label for="Name">Name</label>
                  <input type="text" class="form-control"  name="name" placeholder="Image Name">
                  <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                </div>
                <div class="form-group">
                  <label for="Image">Image</label>
                  <input type="file" name="files" class="form-control"  >
                </div>
                
                <!-- <button type="submit" name="sb" style="background-color: #2E2E2E;" class="btn btn-primary">Add</button> -->
                <input type="submit" name="sub" value="Add" style="background-color: #2E2E2E;" class="btn btn-primary">
              </form>
        </div>
        <div class="modal-footer">
          <button type="button" style="background-color: #2E2E2E; color:white;" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
        </div>
      </div>
    </div>
  </div>
  

  <?php 

if(isset($_POST['sub']))
{
    $user = $_POST['name'];
    $image = $_FILES['files'];
    $image_name = $image['name'];
    echo "<br>";
    echo "<br>";

    $image_temp = $image['tmp_name'];
    $image_error= $image['error'];
    
    $seperator= explode('.', $image_name);
    $lower = strtolower(end($seperator));
  

    $extension= array('jpg','jpeg','png');
    echo "<br>";

    if(in_array($lower,$extension)){

        $upimage = 'fotoo/'.$image_name;
        move_uploaded_file($image_temp,$upimage);

        $sql="insert into `upcoming_movies`(Name,Image) values ('$user','$upimage')" ;

        $res = mysqli_query($con,$sql);

        if($res){

          ?>

          <script>
            // echo"Uploaded successfully!";
            alert("Uploaded Successfully");
            </script>

            <?php
        }
        else{
            echo"Uploading Failed";
        }
    }


}


?>

</nav>
<table class="table table-bordered" style="border:2px solid black;">
  <thead class="thead-light">
  <tr>
    <th scope="col">ID</th>
    <th scope="col">NAME</th>
    <th scope="col">IMAGE</th>
    <th scope="col">ACTION</th>
    
  </tr>
  </thead >
  <tbody>
  <?php
  $qry = "select* from upcoming_movies";
  $res =mysqli_query($con,$qry);
  while($data = mysqli_fetch_array($res)){
    ?>
    <tr>
      <th scope="row"><?php echo $data['ID'] ?></th>
      <td><?php echo $data['Name'] ?></td>
      <td><img height="100px" width="100px" src="<?php echo $data['Image'] ?>" alt=""></td>
      
      <td>

 <a  class="upd" href="updatecrud.php?id=<?php echo $data['ID'] ?>"><button style="padding:3px; font-size:12px;color:white;"  class="btn btn-warning">Update</button></a>

<button type="button" style="padding:5px;font-size:12px; width:50px; height:28px;" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-sm">Delete</button>
</td>
      
    </tr>
  

    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <br>
      <span style="font-weight:bold; font-size:20px; text-align:center;">Are you sure you want to delele this?</span>
           <ul style="display:flex;list-style: none; margin: auto;">
        <li style="margin:5px;"><a class="dlt_btn" href="delete.php?deleteid=<?php echo $data['ID']?>">Yes</a></li>
        <li><button type="button"  style="width:50px;" class="btn btn-secondary"  data-dismiss="modal">NO</button></li>
      </ul>
      
      
      
    
              </div>
  </div>
</div>
<?php
  }
  ?>
  <!-- Modal -->
  





</tbody>
</table>
</div>






<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>
</html>