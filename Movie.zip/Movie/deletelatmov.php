<?php
$con=mysqli_connect("localhost","root","","movie_tickets");
if(!$con){
echo "Connection failed";
}
?>



<?php
$idd=$_GET['id'];
$deletequery="delete from latestmovie where ID=$idd";
$query=mysqli_query($con,$deletequery);
header("location:latmovie.php");

?>

<?php
// $id=$_GET['deleteid'];
// $deletequery="delete from venues where ID=$id";
// $query=mysqli_query($con,$deletequery);
// header("location:Venues.php");

?>