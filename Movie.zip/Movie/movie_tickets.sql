-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2022 at 02:12 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_tickets`
--

-- --------------------------------------------------------

--
-- Table structure for table `latestmovie`
--

CREATE TABLE `latestmovie` (
  `ID` int(100) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Image` varchar(225) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Trailer` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `latestmovie`
--

INSERT INTO `latestmovie` (`ID`, `Name`, `Image`, `Description`, `Trailer`) VALUES
(14, 'Avatar', 'fotoo/avatar.jpg', 'A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home. When his brother is killed in a robbery, paraplegic Marine Jake Sully decides to take his place in a mission on the distant world of Pandora.', 'https://www.youtube.com/embed/d9MyW72ELq0'),
(15, 'Hellowen', 'fotoo/hellowen.jpg', 'Halloween, contraction of All Hallows\' Eve, a holiday observed on October 31, the evening before All Saints\' (or All Hallows\') Day. The celebration marks the day before the Western Christian feast of All Saints and initiates the season of Allhallowtide, which lasts three days and concludes with All Souls\' Day.', 'https://www.youtube.com/embed/ek1ePFp-nBI'),
(16, 'Attack', 'fotoo/attack.jpg', ' Arjun Shergill (John Abraham) is an Indian Army officer, who embarks on a mission to capture Rehman Gul, a dreaded terrorist, who attacked the Indian army convoy two days ago.', 'https://www.youtube.com/embed/Ma3Y-qekYos'),
(17, 'Iron man', 'fotoo/ironman.jpg', 'Synopsis. 2008\'s Iron Man tells the story of Tony Stark, a billionaire industrialist and genius inventor who is kidnapped and forced to build a devastating weapon. Instead, using his intelligence and ingenuity, Tony builds a high-tech suit of armor and escapes captivity.', 'https://www.youtube.com/embed/8ugaeA-nMTc'),
(18, 'Chaudhry', 'fotoo/Chaudhry.jpg', 'When Chaudhry Aslam Khan was martyred in 2014, I was still a student. I remember seeing footage of him in a kurta, freely talking to the officers under him, unshaken by the chaos that was Karachi. He was like a lion strolling through the wilderness, unafraid of what lay before him; come what may. Following his death, he has been celebrated as a hero, and even vilified as a man who took the law into his own hands. He’s a personality worthy of a biopic. Unfortunately, “Chaudhry The Martyr” is unworthy of Chaudhry Aslam Khan', 'https://www.youtube.com/embed/Zb5i26Ws_c0');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `ID` int(100) NOT NULL,
  `Username` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` varchar(400) NOT NULL,
  `Contact` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`ID`, `Username`, `Password`, `Email`, `Address`, `Contact`) VALUES
(4, 'Muhammad Husnain', 'hus123', 'hasnainshaikh@gmail.com', 'karachi', '090934');

-- --------------------------------------------------------

--
-- Table structure for table `spon`
--

CREATE TABLE `spon` (
  `ID` int(100) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Sponsoredby` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `spon`
--

INSERT INTO `spon` (`ID`, `Name`, `Sponsoredby`) VALUES
(8, 'Ary Digital', 'fotoo/ary.jpg'),
(10, 'T series', 'fotoo/tseries.png');

-- --------------------------------------------------------

--
-- Table structure for table `upcoming_movies`
--

CREATE TABLE `upcoming_movies` (
  `ID` int(100) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `upcoming_movies`
--

INSERT INTO `upcoming_movies` (`ID`, `Name`, `Image`) VALUES
(14, 'Black panther', 'fotoo/blackphanter.jpg'),
(15, 'mulajut', 'fotoo/maulajut.jpg'),
(16, 'Avatar', 'fotoo/avatar.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE `venues` (
  `ID` int(100) NOT NULL,
  `Theater` varchar(250) NOT NULL,
  `Image` varchar(250) NOT NULL,
  `Time1` varchar(250) NOT NULL,
  `Time2` varchar(250) NOT NULL,
  `Time3` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venues`
--

INSERT INTO `venues` (`ID`, `Theater`, `Image`, `Time1`, `Time2`, `Time3`) VALUES
(1, 'Capri Cinema', 'fotoo/Nueplex.jpg', '16:00', '20:00', '23:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `latestmovie`
--
ALTER TABLE `latestmovie`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `spon`
--
ALTER TABLE `spon`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `upcoming_movies`
--
ALTER TABLE `upcoming_movies`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `venues`
--
ALTER TABLE `venues`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `latestmovie`
--
ALTER TABLE `latestmovie`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `spon`
--
ALTER TABLE `spon`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `upcoming_movies`
--
ALTER TABLE `upcoming_movies`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `venues`
--
ALTER TABLE `venues`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
