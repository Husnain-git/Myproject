-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2022 at 06:23 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_tickets`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_info`
--

CREATE TABLE `booking_info` (
  `ID` int(100) NOT NULL,
  `User` varchar(300) NOT NULL,
  `Booked Movie` varchar(300) NOT NULL,
  `Tickets` varchar(100) NOT NULL,
  `Time` varchar(100) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Theater` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `latestmovie`
--

CREATE TABLE `latestmovie` (
  `ID` int(100) NOT NULL,
  `Theater_ID` int(100) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Image` varchar(225) NOT NULL,
  `Description` varchar(225) NOT NULL,
  `Trailer` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `latestmovie`
--

INSERT INTO `latestmovie` (`ID`, `Theater_ID`, `Name`, `Image`, `Description`, `Trailer`) VALUES
(18, 4, 'Iron man', 'fotoo/ironman.jpg', 'fter being held captive in an Afghan cave, billionaire engineer Tony Stark creates a unique weaponized suit of armor to fight evil. After being held captive in an Afghan cave, billionaire engineer Tony Stark creates a unique ', '\"https://www.youtube.com/embed/8ugaeA-nMTc'),
(19, 4, 'london nhi jaunga', 'fotoo/london.jpg', 'It is a film about a British girl Zara whose life take a turn when she reads her mothers diary only to find that her father, Mansoor Jami, was brutally murdered under mysterious circumstance due to a love marriage. She return', 'https://www.youtube.com/embed/qAHhNCosiF8'),
(20, 2, 'Chaudhry', 'fotoo/Chaudhry.jpg', 'A Biopic for police officer Aslam Chaudhry who was killed in 2014 in a terrorist attack in Karachi, Pakistan. The film is based on true events. A Biopic for police officer Aslam Chaudhry who was killed in 2014 in a terrorist ', 'https://www.youtube.com/embed/Zb5i26Ws_c0'),
(21, 3, 'Attack', 'fotoo/attack.jpg', 'Arjun Shergill (John Abraham) is an Indian Army officer, who embarks on a mission to capture Rehman Gul, a dreaded terrorist, who attacked the Indian army convoy two days ago', 'https://www.youtube.com/embed/Ma3Y-qekYos'),
(22, 3, 'Hellowen', 'fotoo/hellowen.jpg', 'Plot Summary (6) Fifteen years after murdering his sister on Halloween night 1963, Michael Myers escapes from a mental hospital and returns to the small town of Haddonfield, Illinois to kill again. The year is 1963, the night', 'https://www.youtube.com/embed/ek1ePFp-nBI'),
(23, 2, 'Quaid-e-Azam Zindabad', 'fotoo/quaideazam.jpg', 'Quaid-e-Azam Zindabad is a 2022 Pakistani action-comedy film written by Fizza Ali Meerza and Nabeel Qureshi, directed by Nabeel Qureshi, and produced by Mehdi Ali and Fizza Ali Meerza, under the banners of Filmwala Pictures', 'https://www.youtube.com/embed/f8IQfwadVGw');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `ID` int(100) NOT NULL,
  `Username` varchar(225) NOT NULL,
  `Password` varchar(225) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`ID`, `Username`, `Password`, `Email`, `Address`) VALUES
(6, 'Laraib', 'lar123', 'laraib@gmail.com', 'Liaquatabad'),
(7, 'Husnain', 'hus123', 'hasnainshaikh0306@gmail.com', 'Karachi'),
(8, 'Haris', 'har123', 'haris@gmail.com', 'Baldia Town'),
(9, 'Amir', 'a123', 'amir@gmail.com', 'Karachi'),
(10, 'Muhammad haris', '321piila', 'harisbhai123@gmail.com', 'karachi');

-- --------------------------------------------------------

--
-- Table structure for table `spon`
--

CREATE TABLE `spon` (
  `ID` int(100) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Sponsoredby` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `spon`
--

INSERT INTO `spon` (`ID`, `Name`, `Sponsoredby`) VALUES
(14, 'Nueplex', 'fotoo/Nueplex.jpg'),
(15, 'Atrium mall', 'fotoo/atrium.jfif'),
(16, 'Ary', 'fotoo/ary.jpg'),
(17, 'T series', 'fotoo/tseries.png');

-- --------------------------------------------------------

--
-- Table structure for table `upcoming_movies`
--

CREATE TABLE `upcoming_movies` (
  `ID` int(100) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `upcoming_movies`
--

INSERT INTO `upcoming_movies` (`ID`, `Name`, `Image`) VALUES
(7, 'Maula Jutt', 'fotoo/maulajut.jpg'),
(8, 'Black panther', 'fotoo/blackphanter.jpg'),
(9, 'Wakanda', 'fotoo/Wakanda.jpg'),
(10, 'Avatar', 'fotoo/avatar.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE `venues` (
  `ID` int(100) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Image` varchar(250) NOT NULL,
  `Time1` varchar(100) NOT NULL,
  `Time2` varchar(100) NOT NULL,
  `Time3` varchar(100) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Date2` varchar(100) NOT NULL,
  `Date3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venues`
--

INSERT INTO `venues` (`ID`, `Name`, `Image`, `Time1`, `Time2`, `Time3`, `Date1`, `Date2`, `Date3`) VALUES
(2, 'Nueplex', 'fotoo/Nueplex.jpg', '4PM to 7:30PM', '8PM to 10:30PM', '11PM to 1:30AM', '2022-12-10', '2022-12-11', '2022-12-18'),
(3, 'Shutter', 'fotoo/shutter.png', '4PM to 7:30PM', '8PM to 10:30PM', '11PM to 1:30AM', '2022-12-16', '2022-12-16', '2022-12-14'),
(4, 'Arena', 'fotoo/arena.jpg', '7:30PM to 10:00PM', '10:30PM to 1AM', '4:30PM to 7:30PM', '2023-01-01', '2023-01-07', '2023-01-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_info`
--
ALTER TABLE `booking_info`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `latestmovie`
--
ALTER TABLE `latestmovie`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `spon`
--
ALTER TABLE `spon`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `upcoming_movies`
--
ALTER TABLE `upcoming_movies`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `venues`
--
ALTER TABLE `venues`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_info`
--
ALTER TABLE `booking_info`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `latestmovie`
--
ALTER TABLE `latestmovie`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `spon`
--
ALTER TABLE `spon`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `upcoming_movies`
--
ALTER TABLE `upcoming_movies`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `venues`
--
ALTER TABLE `venues`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
