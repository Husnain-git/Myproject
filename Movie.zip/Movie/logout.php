
<?php
$con = mysqli_connect("localhost", "root", "", "movie_tickets");
if (!$con) {
    echo "Connection failed";
}
?>
<?php
session_start();
session_unset();
session_destroy();
header('location:index.php');


?>
