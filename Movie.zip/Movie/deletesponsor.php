<?php
$con=mysqli_connect("localhost","root","","movie_tickets");
if(!$con){
echo "Connection failed";
}
?>
<?php
$id=$_GET['id'];
$deletequery="delete from spon where ID=$id";
$query=mysqli_query($con,$deletequery);
header("location:sponsor.php");

?>