<?php
$con=mysqli_connect("localhost","root","","movie_tickets");
if(!$con){
echo "Connection failed";
}
?>

<?php
$id=$_GET['deleteid'];
$deletequery="delete from upcoming_movies where ID=$id";
$query=mysqli_query($con,$deletequery);
header("location:Sliderupcoming.php");

?>