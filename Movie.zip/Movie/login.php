<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
      html {
  height: 100%;
}
body {
  margin:0;
  padding:0;
  font-family: sans-serif;
  background: linear-gradient(#e66465, #719);
}
        .container {
  margin: auto;
  /* width :900px; */
  text-align:left;
  
  }
  .container h1,h2{
    text-align:center;
  }
  .container h3{
    text-align:center;
    margin-top: 5px;
  }
  label{
  font-weight:bold;
  font-size:20px;
  color:#6E2C00;
  
}
  input[type=text] {
   border: 3px solid black;
}
input[type=text]:hover {
   border: 3px solid skyblue;
}

input[type=Password] {
   border: 3px solid black;
}
input[type=Password]:hover {
  border: 3px solid skyblue;
}

input[type=Email] {
   border: 3px solid black;
}
input[type=Email]:hover {
   border: 3px solid skyblue;
}
/* button{
  background-color:#DC7633 ;
  color:white;
} */
/* button:hover{
  transform: translatey(3px);
  transition:0.2s;
} */


label{
  font-weight:bold;
  font-size:20px
}
h2{
  color:white;
  font-size:30;
}


.login-box {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 400px;
  padding: 40px;
  transform: translate(-50%, -50%);
  background: linear-gradient(#e66465, #9198e5);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgba(0,0,0,.6);
  border-radius: 10px;
}
.form-group{
  position: relative;
}

.login-box .form-group input:focus ~ label,
.login-box .form-group input:valid ~ label {
  top: -20px;
  left: 0;
  color: #03e9f4;
  font-size: 12px;
}

    </style>

  </head>
<body>

<?php
  $con=mysqli_connect("localhost","root","","movie_tickets") or die(mysql_error());;
  if(!$con){
  echo "Connection failed";
  }
  ?>
<br><br>
                                    <!-- add emplpoyee form popup Modal Body-->
  <div class="container mt-2">
    
  <h2 >Login</h2>
  <hr>
  <div class="login-box">
<form method="POST">
  
                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" name="uname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username">
                  <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" name="pass" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">
                </div>
                
                <button type="submit" name="signup" style="background-color: #2E2E2E; border:2px solid black;" class="btn btn-primary m-3">Login</button>
                <br>
                <a href="signup.php" style="background-color: #2E2E2E; border:2px solid black;" class="btn btn-primary m-3">Signup</a>
                
                
              </form>
              </div>
</div>


                           <!-- php work for login -->
<?php
// if( empty(session_id()) && !headers_sent()){
    session_start();
    if($_SERVER['REQUEST_METHOD']=='POST'){
        if(isset($_POST['signup'])){
            $username = $_POST['uname'];
            $pass = $_POST['pass'];
            $sql="select* from signup where Username ='$username' and Password = '$pass'  ";
            $res = mysqli_query($con,$sql) or die(mysql_error());;
            if($res){
                $num = mysqli_num_rows($res) ;
                if($num>0){
                    $_SESSION['name']=$username;
                    header('Location: index.php');
                    ?>
    <script>
        alert("login");
    </script>
                    <?php
                }
                else{
                    ?>
    <script>
        alert("Incorect Email or password");
    </script>
                    <?php
                    // echo('Login Error');
                }
            }
    
        }
    }
// }


?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>