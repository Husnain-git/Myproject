<?php
$con=mysqli_connect("localhost","root","","movie_tickets");
if(!$con){
echo "Connection failed";
}
?>

<?php
$id=$_GET['deleteid'];
$deletequery="delete from upcoming_movies where ID=$id";
$query=mysqli_query($con,$deletequery);
header("location:Sliderupcoming.php");

?>

<?php
$id=$_GET['deleteid'];
$deletequery="delete from latestmovie where ID=$id";
$query=mysqli_query($con,$deletequery);
header("location:latmovie.php");

?>
<?php
$id=$_GET['deleteid'];
$deletequery="delete from spon where ID=$id";
$query=mysqli_query($con,$deletequery);
header("location:sponsor.php");

?>
<?php
// $id=$_GET['deleteid'];
// $deletequery="delete from venues where ID=$id";
// $query=mysqli_query($con,$deletequery);
// header("location:Venues.php");

?>